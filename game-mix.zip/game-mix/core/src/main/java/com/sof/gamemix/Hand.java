package com.sof.gamemix;

import java.util.ArrayList;

public interface Hand {

    public void add(Card card);

    public void remove(Card card);

    public void emptyHand();

}
