package com.sof.gamemix;

public interface Game {

    public void start();

    public boolean isGameWon();

    public boolean isGameLost();

    public boolean isGameDraw();

    public void reset();
}
