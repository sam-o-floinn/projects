package com.sof.gamemix;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Getter
//@Component
public class CardImpl implements Card {

    // == fields ==
    private final String name;
    private final String type; //should be enum?
    private int value;

    // == constructors ==

    public CardImpl(String name, String type) {
        this.name = name;
        this.type = type;
    }

    // == interface methods ==



    // == methods ==
    //its own method, so we can get values based on
    public void setValue(int value)
    {
        this.value = value;
    }

}
