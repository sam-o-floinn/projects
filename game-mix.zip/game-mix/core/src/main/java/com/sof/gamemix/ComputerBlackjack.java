package com.sof.gamemix;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.util.Random;

@Slf4j
public class ComputerBlackjack implements PlayBJ {

    // == fields ==
    @Getter
    private Hand hand;
    private Deck deck;
    @Getter
    private int value;
    @Getter
    private boolean isHolding;

    // == constructor ==


    public ComputerBlackjack(Hand hand, Deck deck) {
        this.hand = hand;
        this.deck = deck;
        this.value = 0;
        this.isHolding = false;
    }

    // == interface methods ==
    public void draw(Deck deck) {
        log.info("ComputerBlackjack: draw()");


        CardImpl c = deck.draw();
        this.setValue(c);
        hand.add(c);
        this.value += c.getValue();
    }

    @Override
    public void hold() {
        isHolding = true;
    }

    public void noHold() {
        isHolding = false;
    }

    @Override
    public void setAce(CardImpl ace) {
        log.info("Computer drew the " + ace.getName() + " of " + ace.getType());
        if (this.value == 10 ) {
            log.info("The winning combo!");
            ace.setValue(11);
        }
        else if (this.value >= 11) {
            ace.setValue(1);
        }
        else {
            log.info("Computer isn't sure what value to give this ace");
            Random random = new Random();
            ace.setValue(random.nextBoolean() ? 1 : 11);
        }
    }

    @Override
    public void emptyHand() {
        hand.emptyHand();
    }

    public void setValue(CardImpl card) {
        switch(card.getName()) {
            case "Ace":
                this.setAce(card);
                break;
            case "Jack":
            case "King":
            case "Queen":
                card.setValue(10);
                break;
            default: //any numbered case
                card.setValue(Integer.valueOf(card.getName()));
                break;
        }

    }
}
