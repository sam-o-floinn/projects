package com.sof.gamemix;

public interface Card {
    public String getName();

    public String getType();

    public int getValue();

    public void setValue(int value);
}
