package com.sof.gamemix;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@Slf4j
@SpringBootApplication
public class GameMixApplication {

	public static void main(String[] args) {
		log.info("Hello GameMixApplication");
		SpringApplication.run(GameMixApplication.class, args);
	}

}
