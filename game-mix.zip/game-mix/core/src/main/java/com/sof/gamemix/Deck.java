package com.sof.gamemix;

import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.Random;

@Slf4j
public class Deck {

    // == fields ==
    ArrayList<CardImpl> deck = new ArrayList<CardImpl>(52);

    // == constructor ==

    public Deck() {
        this.fillDeck();
    }


    // == methods ==

    public void fillDeck() {
        log.info("Deck: fillDeck()");
        final String[] SUITS = {
                "Clubs", "Hearts", "Diamonds", "Spades"
        };
        final String[] NAMES = {
                "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"
        };

        for (String s: SUITS) {
            for (String n: NAMES) {
                //add a new Card to the Deck with the matching values
                deck.add(new CardImpl(n, s) );
            }
        }
    }

    public CardImpl draw() {
        //remove one card at random from the deck and return it
        log.info("Deck: draw()");
        log.info("DeckSize: {}", deck.size());
        CardImpl c = deck.remove(new Random().nextInt( (deck.size() - 1)));
        return c;
    }

    public void emptyAndFill() {
        log.info("deck: emptyAndFill()");
        deck.clear();
        this.fillDeck();
    }
}
