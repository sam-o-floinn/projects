package com.sof.gamemix;

public interface PlayBJ {
    // == methods ==
    public void draw(Deck deck);

    public void hold(); //no more actions

    public void setAce(CardImpl ace);

    public void emptyHand();

}
