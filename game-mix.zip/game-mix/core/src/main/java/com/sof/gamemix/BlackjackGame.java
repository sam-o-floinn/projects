package com.sof.gamemix;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class BlackjackGame implements Game {

    //== fields ==
    private PlayerBlackjack player;
    private ComputerBlackjack computer;
    private Deck deck;

    @Getter
    private HandImpl playerHand;
    @Getter
    private HandImpl computerHand;

    private boolean isGameOver;

    @Getter
    private int score;
    @Getter
    private int rounds;
    @Getter
    private int turn;
    @Getter
    private String blackjackMsg;

    @Getter
    private Integer compShowCard;


    // == constructor ==

    public BlackjackGame() {
        deck = new Deck();
        playerHand = new HandImpl();
        computerHand = new HandImpl();

        player = new PlayerBlackjack(playerHand, deck);
        computer = new ComputerBlackjack(computerHand, deck);
        rounds = 0;
        score = 0;
        turn = 1;
        isGameOver = false;
        blackjackMsg = "Play Blackjack!";
        compShowCard = null;

    }


    // == interface methods ==

    @Override
    public void start() {
        /*
        1. Player and Computer
        2. while isGameOver() != false, make each Player/Computer Controller take their turn
        3. When isGameOver == true, resolve game score (win, lose, draw)
         */
        while (!isGameOver()) {
            log.info("Blackjack: Turn {}", turn);
            player.draw(deck); //should not be a draw
            computer.draw(deck); //should call a different method instead
            turn ++;
        }
        if (isGameWon()) {
            log.info("YOU WON!");
            score++;
        }

    }

    public void takeTurn() {
        //if (!isGameOver()) {
        log.info("Turn {}", turn);
        if (!(player.isHolding())) {
            log.info("Player is not holding, draw.");
            player.draw(deck);
        } else log.info("Player is holding, don't draw");

        if (computerShouldDraw()) {
            computer.draw(deck);
        } else
            log.info("Computer is holding, don't draw (" + getPlayerHandValue() + ")");

        turn++;
    }

    public boolean computerShouldDraw() {
        // true = draw. false = hold
        if ( (player.isHolding() && getComputerHandValue() > getPlayerHandValue())
            || getComputerHandValue() >= 19
            || getPlayerHandValue() > 21) {
            log.info("Player is done and comp Hand " + getComputerHandValue() + " > "
                + getPlayerHandValue());
            computer.hold();
            return false;
        } else if (computer.isHolding()) {
            log.info("Computer is holding, don't draw");
            return false;
        }
        return true;
    }

    @Override
    public boolean isGameWon() {
        return false;
    }

    @Override
    public boolean isGameLost() {
        return false;
    }

    @Override
    public boolean isGameDraw() {
        return false;
    }

    @Override
    public void reset() {
        log.info("Reset!!!");
        //empty the hands, put everything back into the deck
        player.getHand().emptyHand();//playerHand.emptyHand();
        computer.getHand().emptyHand();

        log.info("Hand values: " + getPlayerHandValue() + ", " + getComputerHandValue());

        player.noHold();
        computer.noHold();

        deck.emptyAndFill();
        turn = 1;
        isGameOver = false;
        compShowCard = null;
        log.info("reset() done!");
    }


    //== methods ==
    public boolean isGameOver() {
        log.info("BlackjackGame: isGameOver()");
        if (getPlayerHandValue() > 21 || getComputerHandValue() > 21) {//(player.getValue() > 21 || computer.getValue() > 21) {
            log.info("Someone has gone bust!");
            log.info("player: " + player.getValue() + ", and comp: " + computer.getValue());
            rounds++;
            isGameOver = getResults();
        }
        else if (player.isHolding() && computer.isHolding()) {
            log.info("Both players are holding!");
            rounds++;
            isGameOver = getResults();
        } else
            log.info("Game is NOT over: "
                + getPlayerHandValue() + " vs " + getComputerHandValue());

        return isGameOver;
    }

    public Boolean getResults() {
        int playValue = getPlayerHandValue();
        int compValue = getComputerHandValue();
        //check for result from bust
        if (getPlayerHandValue() > 21 || getComputerHandValue() > 21) {
            log.info("The game ended because someone went bust. Player: " + getPlayerHandValue() + ", Computer: " + getComputerHandValue());
            if (getPlayerHandValue() < getComputerHandValue()) {
                log.info("Computer went bust. Player wins!");
                score++;
            } else {
                log.info("Player went bust. Computer wins!");
            }
        }        //check for result from hand values
        else if (playValue < compValue) {
            log.info("Outvalued. Player hand " + playValue + " < " + compValue);
        }
        else if (playValue > compValue) {
            log.info("Player wins! " + playValue + " > " + compValue);
            score++;
        } else {
            log.info("Draw! " + playValue + " = " + compValue);
        }
        return true;
    }

    public void playerWon() {
        score++;
        log.info("Player won! Won rounds: {}", score);
    }

    public void playerHold() {
        player.hold();
        log.info("Player is now holding! " + player.isHolding());
    }

    public boolean getPlayerHolding() {
        log.info("Getting player hold status..." + player.isHolding());
        return player.isHolding();
    }

    public int getPlayerHandValue() {
        return playerHand.getHandValue();
    }

    public int getComputerHandValue() {
        return computerHand.getHandValue();
    }

    public void setCompShowCard(int index) {
        compShowCard = index;
    }

    public void setAceValue(int aceValue) {
        int size = playerHand.getHand().size();

        Card lastCard = playerHand.getHand().get(size-1);
        log.info("Last card is the " + lastCard.getName()
                + " of " + lastCard.getType());

        lastCard.setValue(aceValue);
        log.info("CHANGED: Last card is the " + lastCard.getName()
            + " of " + lastCard.getType() + " and now with value " + lastCard.getValue());
    }
}
