package com.sof.gamemix;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PlayerBlackjack implements PlayBJ {

    // == fields ==
    @Getter
    private Hand hand;
    private Deck deck;
    @Getter
    private int value;
    @Getter
    private boolean isHolding;

    // == constructor ==
    public PlayerBlackjack(Hand hand, Deck deck) {
        this.hand = hand;
        this.deck = deck;
        this.value = 0;
        this.isHolding = false;
    }

    // == interface methods ==

    @Override
    public void draw(Deck deck) {
        CardImpl c = deck.draw();

        this.setValue(c);
        hand.add(c);
        this.value += c.getValue();
    }

    @Override
    public void hold() {
        isHolding = true;
    }

    public void noHold() {
        isHolding = false;
    }

    @Override
    public void setAce(CardImpl ace) {
        log.info("You drew the Ace of " + ace.getName() + ". Set it to either 1 or 11.");
        if (this.value <= 10)
            ace.setValue(11);
        else
            ace.setValue(1);
        /*Scanner scanner = new Scanner();
        //int val = scanner.nextInt();
        //obviously this needs a web variant.
        //what could we do? Redirect to a webpage? Set the rest of the project first
        if (val == 1 || val == 11) {
            log.info("Value accepted");
            ace.setValue(val);
        } else {
            log.info("Value must be 1 or 11");
            this.setAce(ace);
        }*/
    }

    @Override
    public void emptyHand() {
        hand.emptyHand();
    }

    public void setValue(CardImpl card) {

        switch(card.getName()) {
            case "Ace":
                this.setAce(card);
                break;
            case "Jack":
            case "King":
            case "Queen":
                card.setValue(10);
                break;
            default: //any numbered case
                card.setValue(Integer.valueOf(card.getName()));
                break;
        }

    }

}
