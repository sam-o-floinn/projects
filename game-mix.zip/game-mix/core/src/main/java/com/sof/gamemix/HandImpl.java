package com.sof.gamemix;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;

@Slf4j
public class HandImpl implements Hand {

    // == fields ==
    @Getter
    ArrayList<Card> hand = new ArrayList<Card>();

    // == methods ==

    public void add(Card c) {
        hand.add(c);
    }

    public void remove(Card c) {
        hand.remove(c);
    }

    public CardImpl getCard(int index) {
        return (CardImpl) hand.get(index);
    }

    public void emptyHand() {
        // empty the hand
        hand.clear();// = new ArrayList<Card>();
        for (Card c: hand) {
            log.info("emptyHand failed! Card " + c.getName());
        }
    }

    public int getHandValue() {
        int val = 0;
        for (Card c: hand) {
            //log.info("Value of card " + c.getName() + " : " + c.getValue());
            val += c.getValue();
        }
        //log.info("Returning value " + val);
        return val;
    }
}
