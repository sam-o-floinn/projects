package com.sof.gamemix.util;

public class AttributeNames {

    public static final String TEST_MESSAGE = "testMessage";
    public static final String SCORE = "score";
    public static final String PLAYER_HAND_VALUE = "handValue";
    public static final String COMPUTER_HAND_VALUE = "computerHandValue";
    public static final String TURN = "turn";
    public static final String ROUNDS = "rounds";
}
