package com.sof.gamemix;

public interface GameService {

    boolean isGameOver();

    String getMainMessage();

    String getTurnMessage();

    String getResultMessage();

    void reset();


}
