package com.sof.gamemix.controllers;

import com.sof.gamemix.util.AttributeNames;
import com.sof.gamemix.util.GameMappings;
import com.sof.gamemix.util.ViewNames;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import javax.management.Attribute;

@Slf4j
@Controller
public class MixController {
    // == fields ==

    // == constructors ==

    // == request methods ==


}
