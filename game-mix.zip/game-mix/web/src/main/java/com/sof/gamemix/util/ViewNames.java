package com.sof.gamemix.util;

public class ViewNames {

    public static final String HOME = "home";
    public static final String BLACKJACK = "blackjack";
    public static final String GAME_OVER = "gameOver";
    public static final String SET_ACE = "setAce";

}
