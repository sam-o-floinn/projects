package com.sof.gamemix;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

@Slf4j
@Service
public class BlackjackService implements GameService {

    // == fields ==
    private final BlackjackGame blackjackGame;

    // == constructor ==
    @Autowired
    public BlackjackService(BlackjackGame blackjackGame) {
        this.blackjackGame = blackjackGame;
    }

    // == init ==
    @PostConstruct
    public void init() {
        log.info("BlackjackService: initiated.");
        log.info("Is game over? {}", this.isGameOver());
    }

    // == interface methods ==
    @Override
    public boolean isGameOver() {
        return blackjackGame.isGameOver();
    }

    @Override
    public String getMainMessage() {
        return "Play Blackjack";
    }

    @Override
    public String getTurnMessage() {
        return "Turn: " + blackjackGame.getTurn();
    }

    @Override
    public String getResultMessage() {
        return "Score: " + blackjackGame.getScore();
    }

    @Override
    public void reset() {
        blackjackGame.reset();
    }

    // == methods ==

    public void takeTurn() {
        log.info("BlackjackService: takeTurn()");
        blackjackGame.takeTurn();
    }

    public int getTurn() {
        return blackjackGame.getTurn();
    }

    public void playerHold() {
        blackjackGame.playerHold();
    }

    public boolean getPlayerHolding() {
        return blackjackGame.getPlayerHolding();
    }

    public int getScore() {
        return blackjackGame.getScore();
    }

    public HandImpl getPlayerHand() { return blackjackGame.getPlayerHand();}
    public HandImpl getComputerHand() { return blackjackGame.getComputerHand();}

    public int getPlayerHandValue() {
        return blackjackGame.getPlayerHandValue();
    }
    public int getComputerHandValue() {
        return blackjackGame.getComputerHandValue();
    }

    public int getRounds() {
        return blackjackGame.getRounds();
    }

    public Integer compShowCard() {
        log.info("getting compShowCard...");
        return blackjackGame.getCompShowCard();
    }

    public void setShowCompCard(int index) {
        blackjackGame.setCompShowCard(index);
    }

    public void setAceValue(int aceValue) {
        blackjackGame.setAceValue(aceValue);
    }

    public String roundResult() {
        if (getPlayerHandValue() > 21) {
            return "Computer Won!";
        } else if (getComputerHandValue() > 21) {
            return "Player Won!";
        }
        else if (getPlayerHandValue() > getComputerHandValue())
            return "Player Won!";
        else if (getComputerHandValue() > getPlayerHandValue())
            return "Computer Won!";
        else
            return "DRAW!";

    }
}
