package com.sof.gamemix.util;

public class GameMappings {
    // == constants ==
    public static final String HOME = "home";
    public static final String BLACKJACK = "blackjack";
    public static final String TAKE_TURN = "takeTurn";
    public static final String REDIRECT_BLACKJACK = "redirect:/" + BLACKJACK;
    public static final String RESET = "reset";
    public static final String PLAYER_HOLD = "playerHold";
    public static final String SHOW_CARD = "showCard";
    public static final String SET_ACE = "setAce";
}
