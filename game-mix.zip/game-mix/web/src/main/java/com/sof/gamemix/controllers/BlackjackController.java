package com.sof.gamemix.controllers;

import com.sof.gamemix.BlackjackService;
import com.sof.gamemix.Card;
import com.sof.gamemix.CardImpl;
import com.sof.gamemix.HandImpl;
import com.sof.gamemix.util.AttributeNames;
import com.sof.gamemix.util.GameMappings;
import com.sof.gamemix.util.ViewNames;
import lombok.extern.slf4j.Slf4j;
import org.apache.catalina.connector.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.Optional;

@Slf4j
@Controller
public class BlackjackController {

    // == fields ==

    private final BlackjackService blackjackService;

    // == constructor ==

    @Autowired
    public BlackjackController(BlackjackService blackjackService) {
        this.blackjackService = blackjackService;
    }

    @ModelAttribute("playerHand")
    public HandImpl getPlayerHand() {
        return blackjackService.getPlayerHand();
    }

    @ModelAttribute("computerHand")
    public HandImpl getComputerHand() {
        return blackjackService.getComputerHand();
    }

    @GetMapping(GameMappings.RESET)
    public String reset(Model model) {
        log.info("reset() called");
        blackjackService.reset();
        return GameMappings.REDIRECT_BLACKJACK;
    }

    // == request mappings ==

    @GetMapping(GameMappings.BLACKJACK)
    public String blackjack(
            Model model,
            @ModelAttribute("playerHand") HandImpl playerHand,
            @ModelAttribute("computerHand") HandImpl computerHand) {

        log.info("model = {}", model);

        log.info("Blackjack called");
        model.addAttribute(AttributeNames.TEST_MESSAGE, "Testing Blackjack!");

        fillModelValues(model, playerHand, computerHand);

        log.info("model = {}", model);

        if (blackjackService.isGameOver()) {
            return gameOver(model, playerHand, computerHand);
        }

        return ViewNames.BLACKJACK;
    }

    public void fillModelValues(Model model,
                                @ModelAttribute HandImpl playerHand,
                                @ModelAttribute HandImpl computerHand) {
        int i = 0;
        int playerSize = playerHand.getHand().size();

        String[] playerCardNames = new String[playerHand.getHand().size()];
        String[] playerCardTypes = new String[playerSize];
        int[] playerCardValues = new int[playerSize];

        for(Card c: playerHand.getHand()) {
            playerCardNames[i] = playerHand.getCard(i).getName();
            playerCardTypes[i] = playerHand.getCard(i).getType();
            playerCardValues[i] = playerHand.getCard(i).getValue();
            i++;
        }

        int j = 0;
        int computerSize = computerHand.getHand().size();

        String[] computerCardNames = new String[computerHand.getHand().size()];
        String[] computerCardTypes = new String[computerSize];
        int[] computerCardValues = new int[computerSize];

        for(Card c: computerHand.getHand()) {
            computerCardNames[j] = computerHand.getCard(j).getName();
            computerCardTypes[j] = computerHand.getCard(j).getType();
            computerCardValues[j] = computerHand.getCard(j).getValue();
            j++;
        }

        model.addAttribute("playerCardNames", playerCardNames);
        model.addAttribute("playerCardTypes", playerCardTypes);
        model.addAttribute("playerCardValues", playerCardValues);

        boolean isPlayerHolding = blackjackService.getPlayerHolding();
        model.addAttribute("playerHold", isPlayerHolding);

        if (blackjackService.compShowCard() != null) {
            log.info("We're showing!");
            Integer showCard = blackjackService.compShowCard();
            model.addAttribute("showCompCard", showCard); //blackjackService.compShowCard());
            model.addAttribute("showCompCardName", blackjackService.getComputerHand().getCard(showCard).getName());
            model.addAttribute("showCompCardType", blackjackService.getComputerHand().getCard(showCard).getType());
            model.addAttribute("showCompCardValue", blackjackService.getComputerHand().getCard(showCard).getValue());
            model.addAttribute("showCompCard", (showCard + 1));

        } else {
            log.info("It appears compShowCard is null: " + blackjackService.compShowCard());
        }

        model.addAttribute("playerValue", playerHand.getHandValue());

        model.addAttribute("computerCardNames", computerCardNames);
        model.addAttribute("computerCardTypes", computerCardTypes);
        model.addAttribute("computerCardValues", computerCardValues);
        model.addAttribute("computerValue", computerHand.getHandValue());
        model.addAttribute("computerHandSize", computerHand.getHand().size());

        model.addAttribute(AttributeNames.SCORE, blackjackService.getScore());
        model.addAttribute(AttributeNames.ROUNDS, blackjackService.getRounds());
        model.addAttribute(AttributeNames.PLAYER_HAND_VALUE, blackjackService.getPlayerHandValue());
        model.addAttribute(AttributeNames.COMPUTER_HAND_VALUE, blackjackService.getComputerHandValue());
        model.addAttribute(AttributeNames.TURN, blackjackService.getTurn());

    }

    @GetMapping(GameMappings.PLAYER_HOLD)
    public String hold() {
        blackjackService.playerHold();
        return GameMappings.REDIRECT_BLACKJACK;
    }

    @GetMapping(GameMappings.SET_ACE)
    public String setAce(int aceVal) {
        log.info("Ace Value = " + aceVal);
        blackjackService.setAceValue(aceVal);
        log.info("Ace set. Redirecting!");
        return GameMappings.REDIRECT_BLACKJACK;
    }

    @GetMapping(GameMappings.SHOW_CARD)
    public String showCard(Model model, Integer cardIndex) {
        log.info("Card Index = " + cardIndex);
        if (getComputerHand().getHand() != null) {
            log.info("computer has a hand");
            log.info("Comp Hand Size: " + getComputerHand().getHand().size());
        }
        if (cardIndex <= getComputerHand().getHand().size()) {
            log.info("index " + cardIndex + " fits under computer hand " + getComputerHand().getHand().size());
            blackjackService.setShowCompCard(cardIndex);
        }
        log.info("showCard model = {}", model);

        return GameMappings.REDIRECT_BLACKJACK;
    }


    @GetMapping(GameMappings.TAKE_TURN)
    public String takeTurn(Model model,
                           @ModelAttribute HandImpl playerHand,
                           @RequestParam(required = false) String playerHold) {
        log.info("TakeTurn() called.");

        if (!blackjackService.isGameOver()) {
            log.info("Taking a turn!");
            blackjackService.takeTurn();
        }
        else {
            log.info("Game is over, no turn taken!");
        }

        int playerSize = blackjackService.getPlayerHand().getHand().size();
        log.info("Player Hand size = " + playerSize);

        log.info("Checking for ace...");
        if (playerSize > 0) {
            if ((blackjackService.getPlayerHand().getCard(playerSize - 1)).getName() == "Ace"
            && ! (blackjackService.getPlayerHolding())) {
                log.info("Last card drawn was an ace!");
                model.addAttribute("playerValue", playerHand.getHandValue());
                return ViewNames.SET_ACE;
            }
            else {
                log.info("Not an ace! Just a "
                        + blackjackService.getPlayerHand().getCard(playerSize - 1).getName());
            }
        } else {
            log.info("Not checking for ace. Player hand size: " + playerSize);
        }

        log.info("REDIRECTING TO BLACKJAAAACK");
        //return blackjack(model, playerHand, computerHand);
        return GameMappings.REDIRECT_BLACKJACK;
    }

    // == game over ==
    public String gameOver(Model model, HandImpl playerHand, HandImpl compHand)
    {
        model.addAttribute("result", blackjackService.roundResult());
        return ViewNames.GAME_OVER;
    }
}

