package com.sof.gamemix;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@Slf4j
@SpringBootApplication
public class WebMain {

    public static void main(String[] args) {
        log.info("Hello WebMain!");
        SpringApplication.run(WebMain.class, args);
    }
}
